# pkg
The easy Debian's Package manager.
